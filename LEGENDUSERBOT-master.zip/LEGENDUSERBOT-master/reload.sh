#!/bin/bash

python3 -m userbot
