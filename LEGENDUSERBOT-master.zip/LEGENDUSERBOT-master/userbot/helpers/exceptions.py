class CancelProcess(Exception):
    """
    Cancel Process
    """

# legendbot
