import logging

from userbot.main_startup import mongo_client
from userbot.main_startup.config_var import Config

db_x = mongo_client["LEGEND"]
