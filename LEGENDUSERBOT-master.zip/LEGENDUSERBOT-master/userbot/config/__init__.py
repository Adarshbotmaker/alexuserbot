from .legendconfig import *
from .vars import Config
