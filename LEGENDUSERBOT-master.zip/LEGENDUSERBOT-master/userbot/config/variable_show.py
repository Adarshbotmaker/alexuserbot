variable_list = [
    "ALIVE_MSG",
    "ALIVE_PIC",
    "AWAKE_PIC",
    "AWAKE_MSG",
    "BIO_MSG",
    "YOUR_GROUP",
    "BUTTONS_IN_HELP",
    "PM_MSG",
    "OP_PIC",
    "PMP_PIC",
    "YOUR_CHANNEL",
    "ALIVE_NAME",
]
